Running web service 

download xampp application

paste the ratetouille folder in xampp\htdocs
paste the database mysql in xampp\mysql

open xampp command line interface and click on "start"
1.) "Apache" (Tomcat server for localhost)
2.) "MySql" (Server for connecting to database)

Once both the service start go to the URL http://localhost/ratetouille/rate-toullie.php

